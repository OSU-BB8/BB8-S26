# BB-8 F26 AprilTag Audio Add-on

## Put it here
Copy `BB8_AprilTag_Audio.py` into:
`F26/BB-8 Code/Head Code/`

Create an `audio` folder inside `Head Code` and put your clips there:
- `audio/tag0.mp3`
- `audio/tag1.mp3`

The script maps AprilTag ID 0 to `tag0.mp3` and ID 1 to `tag1.mp3`.
Edit the `TAG_AUDIO` dictionary near the top of the Python file for your IDs
and filenames. If your printed tags use a different family, update `TAG_FAMILY`.

## Install dependencies on the camera Raspberry Pi
```bash
sudo apt update
sudo apt install -y python3-opencv python3-pygame python3-picamera2
python3 -m pip install pupil-apriltags
```

If your project uses a virtual environment, install the dependencies into that
same environment instead. Do not use `sudo pip`.

## Run a test
1. Stop the existing head/camera program temporarily so it releases the camera.
2. From `Head Code`, run:
   ```bash
   python3 BB8_AprilTag_Audio.py
   ```
3. Show a printed AprilTag from the configured family. The mapped sound should
   play through the audio output configured on this Raspberry Pi.
4. Press Ctrl+C to stop.

## Important integration notes
- This standalone script opens the camera itself. Do not run it at the same time
  as `bb8_head.py` or another detector if that process already owns the camera.
- This version plays sound locally on the Raspberry Pi running the script. It
  does not send an audio command to the body or dome controller.
- If your speaker is connected to a different board, this script needs to send
  a command to that board instead; do not assume the existing body UDP protocol
  supports audio.
- The script assumes the AprilTag family is `tag36h11`, as used in the earlier
  example. Change it to match your project's actual printed tags.
